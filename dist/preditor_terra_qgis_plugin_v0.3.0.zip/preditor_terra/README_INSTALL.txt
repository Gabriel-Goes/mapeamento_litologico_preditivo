Preditor Terra QGIS Plugin - pacote manual

Instalacao manual (QGIS 3.x):
1) Descompacte este zip.
2) Copie a pasta preditor_terra para:
   ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
3) Reinicie o QGIS e ative o plugin Preditor Terra.

Requisitos principais no Python do QGIS:
- numpy, pandas, shapely, pyproj, matplotlib, psycopg2
- opcional: sklearn_som, sklearn, rasterio, pystac_client, verde

Variaveis de ambiente uteis:
- PREDITOR_DATA_BACKEND=postgres
- PREDITOR_PG_HOST, PREDITOR_PG_PORT, PREDITOR_PG_DB, PREDITOR_PG_USER, PREDITOR_PG_PASS
- PREDITOR_PG_GAMA_SOURCE
