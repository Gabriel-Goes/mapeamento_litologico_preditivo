```python
from src import *
from verde_source import regular, interp_at

from tqdm import tqdm
from shapely.ops import transform
from pylab import *
from shapely.geometry import Point, Polygon

import verde as vd
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np 
import geopandas as gpd
import pyproj
import os
```


```python
import warnings
warnings.filterwarnings("ignore")
%load_ext autoreload
%autoreload 2

%matplotlib inline
```


```python
list_geof = os.listdir('/home/ggrl/database/geof/')
list_geof
```




    ['mag_line_1105',
     'mag_1039',
     'gama_line_1105',
     'mag_line_1089',
     'gama_1039',
     'mag_3022',
     'mag_1105',
     'mag_tie_1105',
     'gama_1039_mdt.csv',
     'gama_line_1089',
     'gama_3022',
     'gama_line_1092',
     'geof_1039']



# Construindo Quadrícula


```python
quadricula = Build_mc(escala='50k',ID=['SF23_YB','SF23_YA','SF23_VC','SF23_VD'],verbose=True)
```

    100%|███████████████████████████████████| 4/4 [00:00<00:00, 191.49it/s]
    97it [00:00, 16988.79it/s]

    
     - Folha "SF23_YB_I1" adicionada.
    
     - Folha "SF23_YB_I3" adicionada.
    
     - Folha "SF23_YB_IV1" adicionada.
    
     - Folha "SF23_YB_IV3" adicionada.
    
     - Folha "SF23_YB_I2" adicionada.
    
     - Folha "SF23_YB_I4" adicionada.
    
     - Folha "SF23_YB_IV2" adicionada.
    
     - Folha "SF23_YB_IV4" adicionada.
    
     - Folha "SF23_YB_II1" adicionada.
    
     - Folha "SF23_YB_II3" adicionada.
    
     - Folha "SF23_YB_V1" adicionada.
    
     - Folha "SF23_YB_V3" adicionada.
    
     - Folha "SF23_YB_II2" adicionada.
    
     - Folha "SF23_YB_II4" adicionada.
    
     - Folha "SF23_YB_V2" adicionada.
    
     - Folha "SF23_YB_V4" adicionada.
    
     - Folha "SF23_YB_III1" adicionada.
    
     - Folha "SF23_YB_III3" adicionada.
    
     - Folha "SF23_YB_VI1" adicionada.
    
     - Folha "SF23_YB_VI3" adicionada.
    
     - Folha "SF23_YB_III2" adicionada.
    
     - Folha "SF23_YB_III4" adicionada.
    
     - Folha "SF23_YB_VI2" adicionada.
    
     - Folha "SF23_YB_VI4" adicionada.
    
     - Folha "SF23_YA_I1" adicionada.
    
     - Folha "SF23_YA_I3" adicionada.
    
     - Folha "SF23_YA_IV1" adicionada.
    
     - Folha "SF23_YA_IV3" adicionada.
    
     - Folha "SF23_YA_I2" adicionada.
    
     - Folha "SF23_YA_I4" adicionada.
    
     - Folha "SF23_YA_IV2" adicionada.
    
     - Folha "SF23_YA_IV4" adicionada.
    
     - Folha "SF23_YA_II1" adicionada.
    
     - Folha "SF23_YA_II3" adicionada.
    
     - Folha "SF23_YA_V1" adicionada.
    
     - Folha "SF23_YA_V3" adicionada.
    
     - Folha "SF23_YA_II2" adicionada.
    
     - Folha "SF23_YA_II4" adicionada.
    
     - Folha "SF23_YA_V2" adicionada.
    
     - Folha "SF23_YA_V4" adicionada.
    
     - Folha "SF23_YA_III1" adicionada.
    
     - Folha "SF23_YA_III3" adicionada.
    
     - Folha "SF23_YA_VI1" adicionada.
    
     - Folha "SF23_YA_VI3" adicionada.
    
     - Folha "SF23_YA_III2" adicionada.
    
     - Folha "SF23_YA_III4" adicionada.
    
     - Folha "SF23_YA_VI2" adicionada.
    
     - Folha "SF23_YA_VI4" adicionada.
    
     - Folha "SF23_YA_VI2" adicionada.
    
     - Folha "SF23_VC_I1" adicionada.
    
     - Folha "SF23_VC_I3" adicionada.
    
     - Folha "SF23_VC_IV1" adicionada.
    
     - Folha "SF23_VC_IV3" adicionada.
    
     - Folha "SF23_VC_I2" adicionada.
    
     - Folha "SF23_VC_I4" adicionada.
    
     - Folha "SF23_VC_IV2" adicionada.
    
     - Folha "SF23_VC_IV4" adicionada.
    
     - Folha "SF23_VC_II1" adicionada.
    
     - Folha "SF23_VC_II3" adicionada.
    
     - Folha "SF23_VC_V1" adicionada.
    
     - Folha "SF23_VC_V3" adicionada.
    
     - Folha "SF23_VC_II2" adicionada.
    
     - Folha "SF23_VC_II4" adicionada.
    
     - Folha "SF23_VC_V2" adicionada.
    
     - Folha "SF23_VC_V4" adicionada.
    
     - Folha "SF23_VC_III1" adicionada.
    
     - Folha "SF23_VC_III3" adicionada.
    
     - Folha "SF23_VC_VI1" adicionada.
    
     - Folha "SF23_VC_VI3" adicionada.
    
     - Folha "SF23_VC_III2" adicionada.
    
     - Folha "SF23_VC_III4" adicionada.
    
     - Folha "SF23_VC_VI2" adicionada.
    
     - Folha "SF23_VC_VI4" adicionada.
    
     - Folha "SF23_VD_I1" adicionada.
    
     - Folha "SF23_VD_I3" adicionada.
    
     - Folha "SF23_VD_IV1" adicionada.
    
     - Folha "SF23_VD_IV3" adicionada.
    
     - Folha "SF23_VD_I2" adicionada.
    
     - Folha "SF23_VD_I4" adicionada.
    
     - Folha "SF23_VD_IV2" adicionada.
    
     - Folha "SF23_VD_IV4" adicionada.
    
     - Folha "SF23_VD_II1" adicionada.
    
     - Folha "SF23_VD_II3" adicionada.
    
     - Folha "SF23_VD_V1" adicionada.
    
     - Folha "SF23_VD_V3" adicionada.
    
     - Folha "SF23_VD_II2" adicionada.
    
     - Folha "SF23_VD_II4" adicionada.
    
     - Folha "SF23_VD_V2" adicionada.
    
     - Folha "SF23_VD_V4" adicionada.
    
     - Folha "SF23_VD_III1" adicionada.
    
     - Folha "SF23_VD_III3" adicionada.
    
     - Folha "SF23_VD_VI1" adicionada.
    
     - Folha "SF23_VD_VI3" adicionada.
    
     - Folha "SF23_VD_III2" adicionada.
    
     - Folha "SF23_VD_III4" adicionada.
    
     - Folha "SF23_VD_VI2" adicionada.
    
     - Folha "SF23_VD_VI4" adicionada.
    
      96 folhas adicionadas.


    


# Adicionando dados brutos à Quadrícula


```python
gama_3022,mag_3022=Upload_geof(quadricula,'gama_3022','mag_3022',1100)
gama_1105,mag_1105=Upload_geof(quadricula,'gama_line_1105','mag_line_1105',1100)
gama_1039,mag_1039=Upload_geof(quadricula,'gama_1039','mag_1039',1100)
```

     67%|██████████████████████▋           | 64/96 [00:03<00:01, 18.67it/s]

     - mag_3022 atualizado na folha: SF23_VC_II2 com 6761 pontos
     - gama_3022 atualizado na folha: SF23_VC_II4 com 3905 pontos
     - mag_3022 atualizado na folha: SF23_VC_II4 com 45723 pontos
     - gama_3022 atualizado na folha: SF23_VC_III1 com 6090 pontos


     71%|████████████████████████          | 68/96 [00:03<00:01, 18.40it/s]

     - mag_3022 atualizado na folha: SF23_VC_III1 com 67336 pontos
     - gama_3022 atualizado na folha: SF23_VC_III3 com 24765 pontos
     - mag_3022 atualizado na folha: SF23_VC_III3 com 253598 pontos
     - gama_3022 atualizado na folha: SF23_VC_III2 com 26757 pontos


     73%|████████████████████████▊         | 70/96 [00:03<00:01, 16.86it/s]

     - mag_3022 atualizado na folha: SF23_VC_III2 com 273276 pontos
     - gama_3022 atualizado na folha: SF23_VC_III4 com 47994 pontos
     - mag_3022 atualizado na folha: SF23_VC_III4 com 485208 pontos
     - gama_3022 atualizado na folha: SF23_VC_VI2 com 57765 pontos
     - mag_3022 atualizado na folha: SF23_VC_VI2 com 582782 pontos
     - gama_3022 atualizado na folha: SF23_VC_VI4 com 71617 pontos


     77%|██████████████████████████▏       | 74/96 [00:04<00:01, 16.45it/s]

     - mag_3022 atualizado na folha: SF23_VC_VI4 com 721100 pontos
     - gama_3022 atualizado na folha: SF23_VD_I1 com 73664 pontos
     - mag_3022 atualizado na folha: SF23_VD_I1 com 741336 pontos
     - gama_3022 atualizado na folha: SF23_VD_I3 com 99790 pontos
     - mag_3022 atualizado na folha: SF23_VD_I3 com 1002322 pontos
     - gama_3022 atualizado na folha: SF23_VD_IV1 com 125787 pontos
     - mag_3022 atualizado na folha: SF23_VD_IV1 com 1262224 pontos
     - gama_3022 atualizado na folha: SF23_VD_IV3 com 148900 pontos


     81%|███████████████████████████▋      | 78/96 [00:04<00:01, 15.83it/s]

     - mag_3022 atualizado na folha: SF23_VD_IV3 com 1493007 pontos
     - gama_3022 atualizado na folha: SF23_VD_I2 com 150932 pontos
     - mag_3022 atualizado na folha: SF23_VD_I2 com 1513082 pontos
     - gama_3022 atualizado na folha: SF23_VD_I4 com 177867 pontos
     - mag_3022 atualizado na folha: SF23_VD_I4 com 1782185 pontos
     - gama_3022 atualizado na folha: SF23_VD_IV2 com 204380 pontos


     83%|████████████████████████████▎     | 80/96 [00:04<00:01, 15.15it/s]

     - mag_3022 atualizado na folha: SF23_VD_IV2 com 2047352 pontos
     - gama_3022 atualizado na folha: SF23_VD_IV4 com 228299 pontos
     - mag_3022 atualizado na folha: SF23_VD_IV4 com 2286235 pontos
     - gama_3022 atualizado na folha: SF23_VD_II1 com 230295 pontos
     - mag_3022 atualizado na folha: SF23_VD_II1 com 2305943 pontos
     - gama_3022 atualizado na folha: SF23_VD_II3 com 257265 pontos


     88%|█████████████████████████████▊    | 84/96 [00:04<00:00, 13.91it/s]

     - mag_3022 atualizado na folha: SF23_VD_II3 com 2575370 pontos
     - gama_3022 atualizado na folha: SF23_VD_V1 com 284608 pontos
     - mag_3022 atualizado na folha: SF23_VD_V1 com 2848791 pontos
     - gama_3022 atualizado na folha: SF23_VD_V3 com 308732 pontos
     - mag_3022 atualizado na folha: SF23_VD_V3 com 3089772 pontos
     - gama_3022 atualizado na folha: SF23_VD_II2 com 310665 pontos


     90%|██████████████████████████████▍   | 86/96 [00:04<00:00, 13.45it/s]

     - mag_3022 atualizado na folha: SF23_VD_II2 com 3108850 pontos
     - gama_3022 atualizado na folha: SF23_VD_II4 com 335912 pontos
     - mag_3022 atualizado na folha: SF23_VD_II4 com 3361042 pontos
     - gama_3022 atualizado na folha: SF23_VD_V2 com 362114 pontos
     - mag_3022 atualizado na folha: SF23_VD_V2 com 3622995 pontos
     - gama_3022 atualizado na folha: SF23_VD_V4 com 385317 pontos


     94%|███████████████████████████████▉  | 90/96 [00:05<00:00, 12.23it/s]

     - mag_3022 atualizado na folha: SF23_VD_V4 com 3854789 pontos
     - gama_3022 atualizado na folha: SF23_VD_III1 com 387178 pontos
     - mag_3022 atualizado na folha: SF23_VD_III1 com 3873098 pontos
     - gama_3022 atualizado na folha: SF23_VD_III3 com 410786 pontos
     - mag_3022 atualizado na folha: SF23_VD_III3 com 4108863 pontos
     - gama_3022 atualizado na folha: SF23_VD_VI1 com 434812 pontos


     96%|████████████████████████████████▌ | 92/96 [00:05<00:00, 11.57it/s]

     - mag_3022 atualizado na folha: SF23_VD_VI1 com 4349041 pontos
     - gama_3022 atualizado na folha: SF23_VD_VI3 com 456538 pontos
     - mag_3022 atualizado na folha: SF23_VD_VI3 com 4565931 pontos
     - gama_3022 atualizado na folha: SF23_VD_III2 com 458425 pontos
     - mag_3022 atualizado na folha: SF23_VD_III2 com 4584513 pontos


     98%|█████████████████████████████████▎| 94/96 [00:05<00:00, 11.03it/s]

     - gama_3022 atualizado na folha: SF23_VD_III4 com 481367 pontos
     - mag_3022 atualizado na folha: SF23_VD_III4 com 4813625 pontos
     - gama_3022 atualizado na folha: SF23_VD_VI2 com 504405 pontos
     - mag_3022 atualizado na folha: SF23_VD_VI2 com 5043953 pontos


    100%|██████████████████████████████████| 96/96 [00:05<00:00, 16.44it/s]

     - gama_3022 atualizado na folha: SF23_VD_VI4 com 525310 pontos
     - mag_3022 atualizado na folha: SF23_VD_VI4 com 5252694 pontos


    
      2%|▋                                  | 2/96 [00:00<00:08, 11.18it/s]

     - gama_line_1105 atualizado na folha: SF23_YB_I1 com 20838 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_I1 com 220644 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_I3 com 42949 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_I3 com 444794 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_IV1 com 63902 pontos


      4%|█▍                                 | 4/96 [00:00<00:08, 11.18it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_IV1 com 656231 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_IV3 com 83576 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_IV3 com 871960 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_I2 com 103674 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_I2 com 1089730 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_I4 com 124745 pontos


      6%|██▏                                | 6/96 [00:00<00:08, 10.74it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_I4 com 1309016 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_IV2 com 146392 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_IV2 com 1532239 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_IV4 com 166703 pontos


      8%|██▉                                | 8/96 [00:00<00:08, 10.36it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_IV4 com 1751883 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_II1 com 188052 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_II1 com 1972612 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_II3 com 209273 pontos


     10%|███▌                              | 10/96 [00:00<00:08, 10.09it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_II3 com 2202585 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_V1 com 231404 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_V1 com 2429722 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_V3 com 253888 pontos


     14%|████▌                             | 13/96 [00:01<00:08,  9.74it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_V3 com 2656911 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_II2 com 276542 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_II2 com 2889719 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_II4 com 298986 pontos


     16%|█████▎                            | 15/96 [00:01<00:08,  9.38it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_II4 com 3128113 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_V2 com 321642 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_V2 com 3358389 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_V4 com 342591 pontos


     18%|██████                            | 17/96 [00:01<00:08,  8.85it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_V4 com 3582451 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_III1 com 363473 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_III1 com 3807038 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_III3 com 383780 pontos


     20%|██████▋                           | 19/96 [00:01<00:09,  8.42it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_III3 com 4034476 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_VI1 com 402031 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_VI1 com 4246656 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_VI3 com 422604 pontos


     22%|███████▍                          | 21/96 [00:02<00:09,  7.86it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_VI3 com 4456158 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_III2 com 447105 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_III2 com 4671190 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_III4 com 466066 pontos


     24%|████████▏                         | 23/96 [00:02<00:09,  7.45it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_III4 com 4861831 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_VI2 com 487217 pontos
     - mag_line_1105 atualizado na folha: SF23_YB_VI2 com 5012384 pontos
     - gama_line_1105 atualizado na folha: SF23_YB_VI4 com 513165 pontos


     27%|█████████▏                        | 26/96 [00:02<00:07,  9.18it/s]

     - mag_line_1105 atualizado na folha: SF23_YB_VI4 com 5236028 pontos


     42%|██████████████▏                   | 40/96 [00:03<00:04, 13.53it/s]

     - gama_line_1105 atualizado na folha: SF23_YA_III1 com 514415 pontos
     - mag_line_1105 atualizado na folha: SF23_YA_III1 com 5248564 pontos
     - gama_line_1105 atualizado na folha: SF23_YA_III3 com 515564 pontos


     44%|██████████████▉                   | 42/96 [00:04<00:05, 10.67it/s]

     - mag_line_1105 atualizado na folha: SF23_YA_III3 com 5260162 pontos
     - mag_line_1105 atualizado na folha: SF23_YA_VI1 com 5261347 pontos


     46%|███████████████▌                  | 44/96 [00:04<00:04, 10.41it/s]

     - gama_line_1105 atualizado na folha: SF23_YA_III2 com 537146 pontos
     - mag_line_1105 atualizado na folha: SF23_YA_III2 com 5490051 pontos
     - gama_line_1105 atualizado na folha: SF23_YA_III4 com 558056 pontos


     48%|████████████████▎                 | 46/96 [00:04<00:05,  8.99it/s]

     - mag_line_1105 atualizado na folha: SF23_YA_III4 com 5703780 pontos


     52%|█████████████████▋                | 50/96 [00:04<00:04, 10.23it/s]

     - mag_line_1105 atualizado na folha: SF23_YA_VI4 com 5712754 pontos


     67%|██████████████████████▋           | 64/96 [00:06<00:02, 12.40it/s]

     - mag_line_1105 atualizado na folha: SF23_VC_II4 com 5717730 pontos


     69%|███████████████████████▍          | 66/96 [00:06<00:02, 11.20it/s]

     - gama_line_1105 atualizado na folha: SF23_VC_III3 com 569737 pontos
     - mag_line_1105 atualizado na folha: SF23_VC_III3 com 5835410 pontos
     - gama_line_1105 atualizado na folha: SF23_VC_VI1 com 581225 pontos


     71%|████████████████████████          | 68/96 [00:06<00:02,  9.36it/s]

     - mag_line_1105 atualizado na folha: SF23_VC_VI1 com 5948474 pontos
     - gama_line_1105 atualizado na folha: SF23_VC_VI3 com 585410 pontos
     - mag_line_1105 atualizado na folha: SF23_VC_VI3 com 5990393 pontos


     73%|████████████████████████▊         | 70/96 [00:06<00:02,  9.24it/s]

     - gama_line_1105 atualizado na folha: SF23_VC_III4 com 597678 pontos
     - mag_line_1105 atualizado na folha: SF23_VC_III4 com 6113715 pontos
     - gama_line_1105 atualizado na folha: SF23_VC_VI2 com 614691 pontos


     75%|█████████████████████████▌        | 72/96 [00:07<00:02,  8.08it/s]

     - mag_line_1105 atualizado na folha: SF23_VC_VI2 com 6287003 pontos
     - gama_line_1105 atualizado na folha: SF23_VC_VI4 com 626336 pontos
     - mag_line_1105 atualizado na folha: SF23_VC_VI4 com 6404875 pontos


     78%|██████████████████████████▌       | 75/96 [00:07<00:02,  8.25it/s]

     - mag_line_1105 atualizado na folha: SF23_VD_I3 com 6411540 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_IV1 com 6416951 pontos


     79%|██████████████████████████▉       | 76/96 [00:07<00:02,  6.97it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_IV3 com 627806 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_IV3 com 6432652 pontos


     83%|████████████████████████████▎     | 80/96 [00:08<00:01,  8.75it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_IV4 com 629046 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_IV4 com 6446641 pontos


     88%|█████████████████████████████▊    | 84/96 [00:08<00:01,  9.64it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_V3 com 630178 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_V3 com 6459793 pontos


     92%|███████████████████████████████▏  | 88/96 [00:08<00:00, 10.08it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_V4 com 631496 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_V4 com 6473815 pontos


     96%|████████████████████████████████▌ | 92/96 [00:09<00:00, 10.29it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_VI3 com 632658 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_VI3 com 6486797 pontos


    100%|██████████████████████████████████| 96/96 [00:09<00:00, 10.10it/s]

     - gama_line_1105 atualizado na folha: SF23_VD_VI4 com 634436 pontos
     - mag_line_1105 atualizado na folha: SF23_VD_VI4 com 6500776 pontos


    
     50%|████████████████▌                | 48/96 [00:00<00:00, 105.74it/s]

     - gama_1039 atualizado na folha: SF23_YA_II1 com 8946 pontos
     - mag_1039 atualizado na folha: SF23_YA_II1 com 8946 pontos
     - gama_1039 atualizado na folha: SF23_YA_II3 com 18267 pontos
     - mag_1039 atualizado na folha: SF23_YA_II3 com 18267 pontos
     - gama_1039 atualizado na folha: SF23_YA_V1 com 27485 pontos
     - mag_1039 atualizado na folha: SF23_YA_V1 com 27485 pontos
     - gama_1039 atualizado na folha: SF23_YA_V3 com 36529 pontos
     - mag_1039 atualizado na folha: SF23_YA_V3 com 36529 pontos
     - gama_1039 atualizado na folha: SF23_YA_II2 com 46026 pontos
     - mag_1039 atualizado na folha: SF23_YA_II2 com 46026 pontos
     - gama_1039 atualizado na folha: SF23_YA_II4 com 55601 pontos
     - mag_1039 atualizado na folha: SF23_YA_II4 com 55601 pontos
     - gama_1039 atualizado na folha: SF23_YA_V2 com 64930 pontos
     - mag_1039 atualizado na folha: SF23_YA_V2 com 64930 pontos
     - gama_1039 atualizado na folha: SF23_YA_V4 com 74521 pontos
     - mag_1039 atualizado na folha: SF23_YA_V4 com 74521 pontos
     - gama_1039 atualizado na folha: SF23_YA_III1 com 83828 pontos
     - mag_1039 atualizado na folha: SF23_YA_III1 com 83828 pontos
     - gama_1039 atualizado na folha: SF23_YA_III3 com 93511 pontos
     - mag_1039 atualizado na folha: SF23_YA_III3 com 93511 pontos
     - gama_1039 atualizado na folha: SF23_YA_VI1 com 102842 pontos
     - mag_1039 atualizado na folha: SF23_YA_VI1 com 102842 pontos
     - gama_1039 atualizado na folha: SF23_YA_VI3 com 112428 pontos
     - mag_1039 atualizado na folha: SF23_YA_VI3 com 112428 pontos
     - gama_1039 atualizado na folha: SF23_YA_III2 com 117578 pontos
     - mag_1039 atualizado na folha: SF23_YA_III2 com 117578 pontos
     - gama_1039 atualizado na folha: SF23_YA_III4 com 123266 pontos
     - mag_1039 atualizado na folha: SF23_YA_III4 com 123266 pontos
     - gama_1039 atualizado na folha: SF23_YA_VI4 com 132251 pontos
     - mag_1039 atualizado na folha: SF23_YA_VI4 com 132251 pontos


     74%|████████████████████████▍        | 71/96 [00:00<00:00, 108.68it/s]

     - gama_1039 atualizado na folha: SF23_VC_V3 com 133704 pontos
     - mag_1039 atualizado na folha: SF23_VC_V3 com 133704 pontos
     - gama_1039 atualizado na folha: SF23_VC_V4 com 134864 pontos
     - mag_1039 atualizado na folha: SF23_VC_V4 com 134864 pontos
     - gama_1039 atualizado na folha: SF23_VC_VI3 com 136171 pontos
     - mag_1039 atualizado na folha: SF23_VC_VI3 com 136171 pontos


    100%|█████████████████████████████████| 96/96 [00:00<00:00, 111.29it/s]



```python
geof_list_ids = list(quadricula.keys())

print(len(geof_list_ids))

for id in geof_list_ids:
    print(f' - Folha: {id}')
    carta=quadricula[id]
    for data in list(carta.keys())[2:]:
        print(f'    - {data}')
```

    96
     - Folha: SF23_YB_I1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_I3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_IV1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_IV3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_I2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_I4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_IV2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_IV4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_II1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_II3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_V1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_V3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_II2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_II4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_V2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_V4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_III1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_III3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_VI1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_VI3
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_III2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_III4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_VI2
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YB_VI4
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_YA_I1
     - Folha: SF23_YA_I3
     - Folha: SF23_YA_IV1
     - Folha: SF23_YA_IV3
     - Folha: SF23_YA_I2
     - Folha: SF23_YA_I4
     - Folha: SF23_YA_IV2
     - Folha: SF23_YA_IV4
     - Folha: SF23_YA_II1
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_II3
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_V1
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_V3
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_II2
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_II4
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_V2
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_V4
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_III1
        - gama_line_1105
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_III3
        - gama_line_1105
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_VI1
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_VI3
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_III2
        - gama_line_1105
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_III4
        - gama_line_1105
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_YA_VI2
     - Folha: SF23_YA_VI4
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_VC_I1
     - Folha: SF23_VC_I3
     - Folha: SF23_VC_IV1
     - Folha: SF23_VC_IV3
     - Folha: SF23_VC_I2
     - Folha: SF23_VC_I4
     - Folha: SF23_VC_IV2
     - Folha: SF23_VC_IV4
     - Folha: SF23_VC_II1
     - Folha: SF23_VC_II3
     - Folha: SF23_VC_V1
     - Folha: SF23_VC_V3
        - gama_1039
        - mag_1039
     - Folha: SF23_VC_II2
        - mag_3022
     - Folha: SF23_VC_II4
        - gama_3022
        - mag_3022
        - mag_line_1105
     - Folha: SF23_VC_V2
     - Folha: SF23_VC_V4
        - gama_1039
        - mag_1039
     - Folha: SF23_VC_III1
        - gama_3022
        - mag_3022
     - Folha: SF23_VC_III3
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VC_VI1
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VC_VI3
        - gama_line_1105
        - mag_line_1105
        - gama_1039
        - mag_1039
     - Folha: SF23_VC_III2
        - gama_3022
        - mag_3022
     - Folha: SF23_VC_III4
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VC_VI2
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VC_VI4
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_I1
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_I3
        - gama_3022
        - mag_3022
        - mag_line_1105
     - Folha: SF23_VD_IV1
        - gama_3022
        - mag_3022
        - mag_line_1105
     - Folha: SF23_VD_IV3
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_I2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_I4
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_IV2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_IV4
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_II1
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_II3
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_V1
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_V3
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_II2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_II4
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_V2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_V4
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_III1
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_III3
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_VI1
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_VI3
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105
     - Folha: SF23_VD_III2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_III4
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_VI2
        - gama_3022
        - mag_3022
     - Folha: SF23_VD_VI4
        - gama_3022
        - mag_3022
        - gama_line_1105
        - mag_line_1105



```python
columns = list(quadricula[id].keys())
len(quadricula[id][columns[2]])
```




    20905




```python
quadricula=pop_nodata(quadricula)
len(quadricula.keys())
```

    100%|██████████████████████████████| 96/96 [00:00<00:00, 255166.78it/s]





    60




```python
for id in list(quadricula.keys()):
    
    print(f' - Folha:  {id}')
    carta = quadricula[id]
    print(f'    - {list(carta.keys())}')
```

     - Folha:  SF23_YB_I1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_I3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_IV1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_IV3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_I2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_I4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_IV2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_IV4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_II1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_II3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_V1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_V3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_II2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_II4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_V2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_V4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_III1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_III3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_VI1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_VI3
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_III2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_III4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_VI2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YB_VI4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_YA_II1
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_II3
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_V1
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_V3
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_II2
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_II4
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_V2
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_V4
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_VI3
        - ['folha', 'escala', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_III2
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_III4
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105', 'gama_1039', 'mag_1039']
     - Folha:  SF23_YA_VI4
        - ['folha', 'escala', 'mag_line_1105', 'gama_1039', 'mag_1039']
     - Folha:  SF23_VC_II2
        - ['folha', 'escala', 'mag_3022']
     - Folha:  SF23_VC_III3
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VC_VI1
        - ['folha', 'escala', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VC_III4
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VC_VI2
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VC_VI4
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_I3
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'mag_line_1105']
     - Folha:  SF23_VD_IV1
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'mag_line_1105']
     - Folha:  SF23_VD_IV3
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_I4
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_IV2
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_IV4
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_II3
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_V1
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_V3
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_II4
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_V2
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_V4
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_III3
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_VI1
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_VI3
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']
     - Folha:  SF23_VD_III4
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_VI2
        - ['folha', 'escala', 'gama_3022', 'mag_3022']
     - Folha:  SF23_VD_VI4
        - ['folha', 'escala', 'gama_3022', 'mag_3022', 'gama_line_1105', 'mag_line_1105']



```python
len(quadricula['SF23_YA_V4']['gama_1039'])
```




    9591



## Vizualisando Área de Estudo


```python
plt.figure(figsize=(21,16))
for id in list(quadricula.keys()):
    carta=quadricula[id]
    folha_utm=transform_to_carta_utm(carta['folha'])
    plt.plot(*folha_utm.exterior.xy,color='black')
    #plt.annotate(str(id),xy=folha_utm.centroid.coords[0],textcoords=folha_utm.centroid.coords[0])
    for data in list(carta.keys())[2:]:
        if 'mag' in data:
            pass
        else:
            plt.scatter(carta[data].X,carta[data].Y,c=carta[data].MDT,cmap='terrain',s=0.5,marker='H')
            plt.axis('scaled')
plt.suptitle('Área de cobertura dos levantamentos aerogeofísicos')
plt.tight_layout()
```


    
![png](output_13_0.png)
    


## Visualizando dados Radiométricos Brutos


```python
plot_histograms(gama_3022)
```

                 count         mean          std        min       0.1%        1%   
    CTCOR     525310.0  1272.315511  1720.047778 -11834.130 -132.70365  -12.9291  \
    eTh       525310.0    16.684613    22.942515     -3.800   -0.30000    0.6000   
    eU        525310.0     0.427578     3.353335   -129.300   -2.90000   -1.0000   
    KPERC     525310.0     0.671910     0.924314   -149.323   -0.18600   -0.0910   
    MDT       525310.0   937.394729   144.556802    562.040  578.53309  658.3936   
    THKRAZAO  525310.0   106.517030   593.296064      0.155    0.78800    2.2970   
    UTHRAZAO  525310.0     0.029389     0.038246      0.000    0.00000    0.0010   
    UKRAZAO   525310.0     2.911118    84.418047      0.002    0.00400    0.0060   
    
                    5%      25%       50%        75%        99.95%         max  
    CTCOR     340.8245  719.060  1066.715  1495.9900  14986.650000  450895.020  
    eTh         4.3000    9.000    13.600    19.7000    180.600000    6371.400  
    eU         -0.6000   -0.100     0.200     0.6000     32.069100     934.800  
    KPERC      -0.0150    0.134     0.355     0.8760      7.176000      24.286  
    MDT       772.3700  844.810   901.020   992.0700   1506.794915    1782.280  
    THKRAZAO    5.2500   15.353    35.458    97.7685   1845.198000  205529.094  
    UTHRAZAO    0.0010    0.003     0.016     0.0430      0.410346       1.328  
    UKRAZAO     0.0140    0.094     0.595     2.1440     77.079000   30156.090  



    
![png](output_15_1.png)
    



```python
plot_raw_gama_data(gama_3022,suptitle='Dados Radiométricos brutos (Gama_3022.XYZ)')
```


    
![png](output_16_0.png)
    



```python
plot_boxplots(gama_1105,gama_FEAT)
```


    
![png](output_17_0.png)
    



```python
plot_histograms(gama_1105)
```

                 count         mean         std      min        0.1%         1%   
    CTCOR     634436.0    10.984453    9.035009   -2.947    1.047000    2.41635  \
    eTh       634436.0    18.916825    9.479077   -3.080    2.199000    4.75000   
    eU        634436.0     1.647297    1.010514   -0.500   -0.401000   -0.08900   
    KPERC     634436.0     0.909209    0.715278   -0.499   -0.329000   -0.07700   
    MDT       634436.0  1042.974653  289.630767  513.280  521.130000  532.14350   
    THKRAZAO  634436.0    31.907327   29.382652    1.079    2.655435    4.98135   
    UTHRAZAO  634436.0     0.095015    0.042974    0.000    0.000000    0.02100   
    UKRAZAO   634436.0     2.808605    2.579272    0.046    0.161000    0.30000   
    
                   5%      25%      50%       75%       99.95%       max  
    CTCOR       3.510    5.778    8.235    12.591   103.678250   246.600  
    eTh         7.186   12.131   17.384    23.765    85.542900   223.136  
    eU          0.320    0.977    1.518     2.155     9.460000    23.934  
    KPERC       0.115    0.411    0.733     1.225     5.309000     7.840  
    MDT       567.780  864.650  974.980  1229.180  1997.231200  2326.220  
    THKRAZAO    7.650   13.883   22.470    38.717   259.447173   505.144  
    UTHRAZAO    0.043    0.068    0.091     0.109     0.407000     2.311  
    UKRAZAO     0.544    1.192    2.025     3.512    24.311213    59.007  



    
![png](output_18_1.png)
    



```python
plot_raw_gama_data(gama_1105,suptitle='DADOS AEROGAMAESPECTROMÉTRICO')
```


    
![png](output_19_0.png)
    



```python
gama_1039.rename(columns={'CTC':'CTCOR','KC':'KPERC','UC':'eU','THC':'eTh'},inplace=True)

```


```python
gama_1039_positive=remove_negative_values(gama_1039,lista=['X','Y','LATITUDE','LONGITUDE','geometry'])

gama_1039_positive['UTHRAZAO']=gama_1039_positive['eU']/gama_1039_positive['eTh']
gama_1039_positive['UKRAZAO']=gama_1039_positive['eU']/gama_1039_positive['KPERC']
gama_1039_positive['THKRAZAO']=gama_1039_positive['eTh']/gama_1039_positive['KPERC']
```

    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - CTCOR
    Atributo - MDT



```python
plot_boxplots(gama_1039,gama_FEAT)
```


    
![png](output_22_0.png)
    



```python
plot_histograms(gama_1039)
```

                 count         mean          std         min        0.1%   
    CTCOR     136171.0  1217.949255   695.287355    0.001000   84.408400  \
    eTh       136171.0    65.590583    42.358837    0.001000    0.001000   
    eU        136171.0    16.948117    11.460870    0.001000    0.001000   
    KPERC     136171.0    59.925998    64.414913    0.001000    0.001000   
    MDT       136171.0   685.486466   118.314475  494.500000  503.537669   
    THKRAZAO  136171.0   998.951773  7051.884789    0.000005    0.001675   
    UTHRAZAO  136171.0     8.633204   337.152505    0.000002    0.000005   
    UKRAZAO   136171.0   432.079279  3132.728481    0.000002    0.000004   
    
                      1%          5%         25%          50%          75%   
    CTCOR     300.397000  469.025000  736.690000  1025.230000  1518.265000  \
    eTh         9.757000   19.610000   36.190000    54.200000    83.620000   
    eU          0.001000    0.001000    8.820000    15.580000    23.300000   
    KPERC       0.001000    3.895000   18.590000    35.940000    77.220000   
    MDT       530.376184  559.067596  605.423828   650.630859   728.902435   
    THKRAZAO    0.176338    0.306527    0.732829     1.526891     2.905699   
    UTHRAZAO    0.000009    0.000093    0.146673     0.277410     0.455387   
    UKRAZAO     0.000009    0.000345    0.149515     0.377850     0.870926   
    
                    99.95%            max  
    CTCOR      5265.903900    6797.270000  
    eTh         312.873050     509.050000  
    eU           78.209800     179.140000  
    KPERC       414.609400     566.690000  
    MDT        1396.717191    1616.607056  
    THKRAZAO  95578.300000  192660.000000  
    UTHRAZAO   6247.450000   35840.000000  
    UKRAZAO   40006.600000   71460.000000  



    
![png](output_23_1.png)
    



```python
plot_histograms(gama_1039_positive)
```

                 count         mean          std         min        0.1%   
    CTCOR     136171.0  1217.949255   695.287355    0.001000   84.408400  \
    eTh       136171.0    65.590583    42.358837    0.001000    0.001000   
    eU        136171.0    16.948117    11.460870    0.001000    0.001000   
    KPERC     136171.0    59.925998    64.414913    0.001000    0.001000   
    MDT       136171.0   685.486466   118.314475  494.500000  503.537669   
    THKRAZAO  136171.0   998.951773  7051.884789    0.000005    0.001675   
    UTHRAZAO  136171.0     8.633204   337.152505    0.000002    0.000005   
    UKRAZAO   136171.0   432.079279  3132.728481    0.000002    0.000004   
    
                      1%          5%         25%          50%          75%   
    CTCOR     300.397000  469.025000  736.690000  1025.230000  1518.265000  \
    eTh         9.757000   19.610000   36.190000    54.200000    83.620000   
    eU          0.001000    0.001000    8.820000    15.580000    23.300000   
    KPERC       0.001000    3.895000   18.590000    35.940000    77.220000   
    MDT       530.376184  559.067596  605.423828   650.630859   728.902435   
    THKRAZAO    0.176338    0.306527    0.732829     1.526891     2.905699   
    UTHRAZAO    0.000009    0.000093    0.146673     0.277410     0.455387   
    UKRAZAO     0.000009    0.000345    0.149515     0.377850     0.870926   
    
                    99.95%            max  
    CTCOR      5265.903900    6797.270000  
    eTh         312.873050     509.050000  
    eU           78.209800     179.140000  
    KPERC       414.609400     566.690000  
    MDT        1396.717191    1616.607056  
    THKRAZAO  95578.300000  192660.000000  
    UTHRAZAO   6247.450000   35840.000000  
    UKRAZAO   40006.600000   71460.000000  



    
![png](output_24_1.png)
    



```python
plot_raw_gama_data(gama_1039,suptitle='Dados Radiométricos brutos (XYZ)',orientation='vertical')
```


    
![png](output_25_0.png)
    


## Removendo valores negativos das contagens radiométricas


```python
gama_3022_positive = remove_negative_values(gama_3022)
```

    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO



```python
plot_boxplots(gama_3022_positive,gama_FEAT)
```


    
![png](output_28_0.png)
    



```python
plot_histograms(gama_3022_positive)
```

                 count         mean          std      min       0.1%        1%   
    CTCOR     525310.0  1273.519179  1717.829015    0.001    0.00100    0.0010  \
    eTh       525310.0    16.685630    22.941761    0.001    0.00100    0.6000   
    eU        525310.0     0.548357     3.201134    0.001    0.00100    0.0010   
    KPERC     525310.0     0.676153     0.860617    0.001    0.00100    0.0010   
    MDT       525310.0   937.394729   144.556802  562.040  578.53309  658.3936   
    THKRAZAO  525310.0   106.517030   593.296064    0.155    0.78800    2.2970   
    UTHRAZAO  525310.0     0.029394     0.038242    0.001    0.00100    0.0010   
    UKRAZAO   525310.0     2.911118    84.418047    0.002    0.00400    0.0060   
    
                    5%      25%       50%        75%        99.95%         max  
    CTCOR     340.8245  719.060  1066.715  1495.9900  14986.650000  450895.020  
    eTh         4.3000    9.000    13.600    19.7000    180.600000    6371.400  
    eU          0.0010    0.001     0.200     0.6000     32.069100     934.800  
    KPERC       0.0010    0.134     0.355     0.8760      7.176000      24.286  
    MDT       772.3700  844.810   901.020   992.0700   1506.794915    1782.280  
    THKRAZAO    5.2500   15.353    35.458    97.7685   1845.198000  205529.094  
    UTHRAZAO    0.0010    0.003     0.016     0.0430      0.410346       1.328  
    UKRAZAO     0.0140    0.094     0.595     2.1440     77.079000   30156.090  



    
![png](output_29_1.png)
    



```python
plot_raw_gama_data(gama_3022_positive,'Dados radiométricos tratadas : value <= 0 == 0.001')
```


    
![png](output_30_0.png)
    



```python
gama_1105_positive = remove_negative_values(gama_1105)
```

    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR



```python
plot_histograms(gama_1105_positive)
```

                 count         mean         std      min        0.1%         1%   
    CTCOR     634436.0    10.984530    9.034912    0.001    1.047000    2.41635  \
    eTh       634436.0    18.916906    9.478910    0.001    2.199000    4.75000   
    eU        634436.0     1.649881    1.005950    0.001    0.001000    0.00100   
    KPERC     634436.0     0.911423    0.712131    0.001    0.001000    0.00100   
    MDT       634436.0  1042.974653  289.630767  513.280  521.130000  532.14350   
    THKRAZAO  634436.0    31.907327   29.382652    1.079    2.655435    4.98135   
    UTHRAZAO  634436.0     0.095022    0.042958    0.001    0.001000    0.02100   
    UKRAZAO   634436.0     2.808605    2.579272    0.046    0.161000    0.30000   
    
                   5%      25%      50%       75%       99.95%       max  
    CTCOR       3.510    5.778    8.235    12.591   103.678250   246.600  
    eTh         7.186   12.131   17.384    23.765    85.542900   223.136  
    eU          0.320    0.977    1.518     2.155     9.460000    23.934  
    KPERC       0.115    0.411    0.733     1.225     5.309000     7.840  
    MDT       567.780  864.650  974.980  1229.180  1997.231200  2326.220  
    THKRAZAO    7.650   13.883   22.470    38.717   259.447173   505.144  
    UTHRAZAO    0.043    0.068    0.091     0.109     0.407000     2.311  
    UKRAZAO     0.544    1.192    2.025     3.512    24.311213    59.007  



    
![png](output_32_1.png)
    



```python
plot_boxplots(gama_1105_positive,gama_FEAT)
```


    
![png](output_33_0.png)
    



```python
plot_raw_gama_data(gama_1105_positive,'Dados radiométricos tratadas : value <= 0 == 0.001')
```


    
![png](output_34_0.png)
    



```python
plot_histograms(gama_1039_positive)
plot_raw_gama_data(gama_1039_positive,'Dados radiométricos tratadas : value <= 0 == 0.001')
```

                 count         mean          std         min        0.1%   
    CTCOR     136171.0  1217.949255   695.287355    0.001000   84.408400  \
    eTh       136171.0    65.590583    42.358837    0.001000    0.001000   
    eU        136171.0    16.948117    11.460870    0.001000    0.001000   
    KPERC     136171.0    59.925998    64.414913    0.001000    0.001000   
    MDT       136171.0   685.486466   118.314475  494.500000  503.537669   
    THKRAZAO  136171.0   998.951773  7051.884789    0.000005    0.001675   
    UTHRAZAO  136171.0     8.633204   337.152505    0.000002    0.000005   
    UKRAZAO   136171.0   432.079279  3132.728481    0.000002    0.000004   
    
                      1%          5%         25%          50%          75%   
    CTCOR     300.397000  469.025000  736.690000  1025.230000  1518.265000  \
    eTh         9.757000   19.610000   36.190000    54.200000    83.620000   
    eU          0.001000    0.001000    8.820000    15.580000    23.300000   
    KPERC       0.001000    3.895000   18.590000    35.940000    77.220000   
    MDT       530.376184  559.067596  605.423828   650.630859   728.902435   
    THKRAZAO    0.176338    0.306527    0.732829     1.526891     2.905699   
    UTHRAZAO    0.000009    0.000093    0.146673     0.277410     0.455387   
    UKRAZAO     0.000009    0.000345    0.149515     0.377850     0.870926   
    
                    99.95%            max  
    CTCOR      5265.903900    6797.270000  
    eTh         312.873050     509.050000  
    eU           78.209800     179.140000  
    KPERC       414.609400     566.690000  
    MDT        1396.717191    1616.607056  
    THKRAZAO  95578.300000  192660.000000  
    UTHRAZAO   6247.450000   35840.000000  
    UKRAZAO   40006.600000   71460.000000  



    
![png](output_35_1.png)
    



    
![png](output_35_2.png)
    


## CONSTRUINDO UM GRID SINTÉTICO


```python
# REMOVING PART OF THE SINTETIC GRID
'''
df_xu_yu = pd.DataFrame(np.array([xu,yu]))
df_xu_yu=df_xu_yu.T
df_xu_yu.rename(columns={0:'xu',1:'yu'},inplace=True)

df_xu_yu[(df_xu_yu.xu < 540937) & (df_xu_yu.yu > 8866937)]

df_xu_yu.drop(df_xu_yu[(df_xu_yu.xu < 540937) & (df_xu_yu.yu > 8866937)].index,inplace=True)
plt.figure(figsize=(18,12))

plt.scatter(df_xu_yu.xu,df_xu_yu.yu,s=0.1,marker='.')
plt.axis('scaled')
'''
```

# Interpolação dos dados Brutos

## Método Cúbico


```python
# Test de área

# area=(344093.45426573796, 396417.36691108724, 7621768.799495494, 7677527.304557458)
# int((area[3]-area[2])/100),int((area[1]-area[0])/100)
```


```python
#traditional_interpolation(quadricula,'mag_3022','gama_3022','cubic','geof_3022')
```


```python
#list(quadricula['SF23_VC'].keys())
```


```python

#df = quadricula['SF23_VC']['geof_3022_cubic']
#plt.figure(figsize=(12,12))
#plt.scatter(x=df.X,y=df.Y,c=df.GMT,cmap='rainbow')
#plt.axis('scaled')
```


```python
# Print the output. a=

#descript_cubic = df.describe(percentiles)
#descript_cubic[['eU','eTh','KPERC','CTCOR','UTHRAZAO','THKRAZAO','UKRAZAO']].T
```


```python
#plot_histograms(geof_1089_cubic,suptitle='Distribuição dos dados radiométricos interpolados (cúbico, pixel 100m)')
#plot_raw_data(geof_1089_cubic,suptitle='Dados radiométricos interpolados (cúbico, pixel 100m)')
```

## Método Nearest


```python
#plot_histograms(geof_1089_nearest,suptitle='Distribuição dos dados radiométricos interpolados (nearest, pixel 100m)')
```


```python
#plot_raw_data(geof_1089_nearest,suptitle='Dados radiométricos interpolados (nearest, pixel 100m)')
```

## Método Linear


```python
traditional_interpolation(quadricula,'mag_3022','gama_3022','linear','geof_3022')
```

     - Folha: SF23_VC_III3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VC_III4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VC_VI2
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VC_VI4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_I3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_IV1
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_IV3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_I4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_IV2
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_IV4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_II3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_V1
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_V3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_II4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_V2
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_V4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_III3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_VI1
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_VI3
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_III4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_VI2
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')
     - Folha: SF23_VD_VI4
    Atributo - ALTURA
    Atributo - MAGIGRF
    Atributo - MDT
    Atributo - CTCOR
    Atributo - eTh
    Atributo - eU
    Atributo - KPERC
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - UKRAZAO
    Atributo - UTHRAZAO
    Index(['ALTURA', 'LATITUDE', 'LONGITUDE', 'MAGIGRF', 'MDT', 'X', 'Y'], dtype='object')



```python
traditional_interpolation(quadricula,'mag_line_1105','gama_line_1105','linear','geof_1105')
```

     - Folha: SF23_YB_I1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_I3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_IV1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_IV3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_I2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_I4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_IV2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_IV4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_II1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_II3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_V1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_V3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_II2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_II4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_V2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_V4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_III1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_III3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_VI1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_VI3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_III2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_III4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_VI2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YB_VI4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YA_III2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_YA_III4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VC_III3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VC_VI1
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VC_III4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VC_VI2
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VC_VI4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_IV3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_IV4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_V3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_V4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_VI3
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')
     - Folha: SF23_VD_VI4
    Atributo - ALTURA
    Atributo - MDT
    Atributo - ALTURA_1
    Atributo - MAGIGRF
    Atributo - KPERC
    Atributo - eU
    Atributo - eTh
    Atributo - UTHRAZAO
    Atributo - UKRAZAO
    Atributo - MDT
    Atributo - THKRAZAO
    Atributo - CTCOR
    Index(['ALTURA', 'X', 'Y', 'MDT', 'LATITUDE', 'LONGITUDE', 'ALTURA_1',
           'MAGIGRF'],
          dtype='object')



```python
plt.figure(figsize=(24,16))

# PLOTANDO A MALHA CARTOGRÁFICA
for id in list(quadricula.keys()):
    carta=quadricula[id]
    plt.plot(*transform_to_carta_utm(carta['folha']).exterior.xy,color='black')
    
    # PLOTANDO OS DADOS INTERPOLADOS
    for data in list(carta.keys())[2:]:        
        if 'geof' in data:
            plt.scatter(carta[data].X,carta[data].Y,c=carta[data].eU,cmap='rainbow',s=0.5,marker='H')
            plt.axis('scaled')
        # SE NÃO TIVER DADOS NÃO PLOTA NADA
        else:
            pass
        
plt.suptitle('Área de cobertura dos levantamentos aerogeofísicos')
plt.tight_layout()
```


    
![png](output_52_0.png)
    



```python
traditional_interpolation(quadricula,'mag_1039','gama_1039','linear','geof_1039')
```

     - Folha: SF23_YA_II1
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_II3
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_V1
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_V3
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_II2
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_II4
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_V2
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_V4
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_VI3
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_III2
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_III4
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')
     - Folha: SF23_YA_VI4
    Atributo - MDT
    Atributo - MAGR
    Atributo - THC
    Atributo - UC
    Atributo - KC
    Atributo - CTC
    Atributo - MDT
    Index(['X', 'Y', 'LONGITUDE', 'LATITUDE', 'MDT', 'MAGIGRF'], dtype='object')



```python
plt.figure(figsize=(24,16))

for id in list(quadricula.keys()):
    carta=quadricula[id]
    plt.plot(*transform_to_carta_utm(carta['folha']).exterior.xy,color='black')
    
    for data in list(carta.keys())[2:]:
        if 'geof' in data:
            plt.scatter(carta[data].X,carta[data].Y,c=carta[data].MDT,cmap='terrain',s=0.5,marker='H')
            plt.axis('scaled')
        else:
            pass
        
plt.suptitle('Área de cobertura dos levantamentos aerogeofísicos')
plt.tight_layout()

```


    
![png](output_54_0.png)
    


# Classificações Não-Supervisionadas

## Self-organizing maps (SOM)


```python
import matplotlib
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn_som.som import SOM

def plot_corr(dataframe, size=10):
    plt.figure(figsize = (size+size*0.2, size), facecolor='w')
    corrMatrix = dataframe.corr()
    sns.heatmap(np.round(corrMatrix,2), annot=True)
    plt.xticks(rotation=90, ha='right')
    plt.yticks(rotation=0, ha='right')

```

### SF23_YA_III2


```python
SF23_YA_III2 = quadricula['SF23_YA_III2']['geof_1105_linear']
plot_histograms(SF23_YA_III2)

plot_boxplots(SF23_YA_III2,gama_FEAT)

plot_raw_gama_data(SF23_YA_III2,suptitle='Dados Radiométricos interpolados (Algoritmo: Linear)',figsize=(27,16))

SF23_YA_III2.rename(columns={'GMT':'MAGIGRF'},inplace=True)
plot_raw_mag_data(SF23_YA_III2,suptitle='Dados Magnetométricos interpolados (Algoritmo: Linear)')
```

                count         mean         std         min        0.1%   
    CTCOR     72540.0    10.638862    5.618974    1.182279    2.467299  \
    eTh       72540.0    23.650289   10.158650    3.002149    5.504152   
    eU        72540.0     1.972517    1.214947    0.001000    0.041367   
    KPERC     72540.0     1.584911    0.989897    0.001000    0.017541   
    MDT       72540.0  1020.039836  169.907884  765.115344  777.458619   
    THKRAZAO  72540.0    23.091371   20.593088    2.848998    3.232426   
    UTHRAZAO  72540.0     0.085738    0.029095    0.001000    0.017097   
    UKRAZAO   72540.0     1.912889    1.693197    0.076108    0.148513   
    
                      1%          5%         25%         50%          75%   
    CTCOR       3.395509    4.769986    7.394854    9.506086    12.413033  \
    eTh         7.803473   11.097638   16.381003   21.654381    28.772409   
    eU          0.248314    0.585850    1.195337    1.713486     2.446279   
    KPERC       0.133043    0.334360    0.797496    1.362108     2.249035   
    MDT       803.026854  837.689886  891.712173  951.096822  1129.656695   
    THKRAZAO    3.943695    5.204732   10.034796   16.977392    29.158873   
    UTHRAZAO    0.033741    0.047818    0.066281    0.081524     0.099820   
    UKRAZAO     0.244175    0.371279    0.810780    1.397482     2.440711   
    
                   99.95%          max  
    CTCOR       71.016670   124.701324  
    eTh         81.801741    92.900788  
    eU          13.013598    20.393412  
    KPERC        5.328469     7.126128  
    MDT       1571.431816  1605.059307  
    THKRAZAO   223.738709   302.639945  
    UTHRAZAO     0.250323     0.298661  
    UKRAZAO     15.600006    25.675944  



    
![png](output_59_1.png)
    



    
![png](output_59_2.png)
    



    
![png](output_59_3.png)
    



    
![png](output_59_4.png)
    



```python
SF23_YA_III2.rename(columns={'X':'E_utm','Y':'N_utm'},inplace=True)
#df_rs.fillna(0,inplace=True)

xpixel_size = (SF23_YA_III2.E_utm.max()-SF23_YA_III2.E_utm.min())/SF23_YA_III2.E_utm.unique().size
ypixel_size = (SF23_YA_III2.N_utm.max()-SF23_YA_III2.N_utm.min())/SF23_YA_III2.N_utm.unique().size
print('x:', xpixel_size, 'y:', ypixel_size)

nx=SF23_YA_III2.E_utm.unique().size
ny=SF23_YA_III2.N_utm.unique().size
ratio=ny/nx
xs = SF23_YA_III2.E_utm.values.reshape(ny, nx)
ys = SF23_YA_III2.N_utm.values.reshape(ny, nx)

features = list(SF23_YA_III2.columns[2:])

plot_corr(SF23_YA_III2[features], size=11)
#plt.savefig('figs/correlation_matrix.png', dpi=400, bbox_inches='tight')
```

    x: 100.3297046847816 y: 100.19910621095956



    
![png](output_60_1.png)
    



```python
data = StandardScaler().fit_transform(SF23_YA_III2[features].values)

# data = df_rs[features].values

# NÚMERO DE CLASSES
n_clusters=11
lito_SOM = SOM(m=n_clusters,
               n=1,
           sigma=1.5,
             dim=len(features),
        max_iter=10000)

lito_SOM.fit(data)

# predição de classes
predictions = lito_SOM.predict(data)

# create labels
cluster_labels=[]
for i in range(n_clusters):
    cluster_labels+=[f'Classe {i+1}']
    
# classes weights
fig, ax = plt.subplots(figsize=(19,19))
im=ax.matshow(lito_SOM.weights)
for (i, j), z in np.ndenumerate(lito_SOM.weights):
    ax.text(j, i, '{:0.2f}'.format(z), ha='center', va='center')

plt.yticks(range(n_clusters), cluster_labels, fontsize=9)
plt.xticks(range(len(features)), features, rotation=55, fontsize=10, ha='left')
fig.colorbar(im, label='weights', orientation='horizontal')
plt.gca().set_aspect('equal')
plt.gcf().set_size_inches(10, 10)
plt.show()
```


    
![png](output_61_0.png)
    



```python
id_ = [1,2,3,4,5,6,7,8,9,10,11]
relcolor =  matplotlib.cm.Set3
colors = np.array(relcolor.colors)[id_]
relcolor = matplotlib.colors.ListedColormap(colors)

idxs=np.arange(0, n_clusters, 1)
half=(idxs[1]-idxs[0])/2
ticks=np.linspace(idxs[0]+half, idxs[-1]-half, n_clusters)

datafig, ax=plt.subplots(figsize=(12, 12), facecolor='w')
im=plt.pcolormesh(xs, ys, predictions.reshape(ny, nx), cmap=relcolor, shading='auto')
plt.xlim(xs.min(), xs.max())
plt.ylim(ys.min(), ys.max())

cbar_ax = fig.add_axes([0.93, 0.3, 0.05, 0.4])
cbar = fig.colorbar(im, cax=cbar_ax, label = u'Classes', orientation='vertical',cmap='viridis',ticks=ticks)
cbar.ax.set_yticklabels(cluster_labels, fontsize=8)


plt.suptitle('SOM - Aerogeophysical Data (SF23_YA_III4)')
plt.axis('scaled')
plt.tight_layout()
plt.show()

```


    
![png](output_62_0.png)
    


### SF23_YA_III4


```python
df = quadricula['SF23_YA_III4']['geof_1105_linear']
plot_histograms(df)
```

                count        mean         std         min        0.1%          1%   
    CTCOR     72540.0    6.556830    2.713995    1.382123    1.918697    2.511803  \
    eTh       72540.0   14.111952    5.510771    1.681087    3.412660    5.263821   
    eU        72540.0    1.631743    0.700655    0.001000    0.053025    0.273024   
    KPERC     72540.0    1.097175    0.695084    0.001000    0.012373    0.080317   
    MDT       72540.0  856.902556  101.569635  627.918941  631.338414  648.888914   
    THKRAZAO  72540.0   19.543967   16.943119    2.929159    3.615296    4.550159   
    UTHRAZAO  72540.0    0.121622    0.036082    0.016837    0.035372    0.054940   
    UKRAZAO   72540.0    2.345212    2.136472    0.146864    0.294002    0.468174   
    
                      5%         25%         50%         75%       99.95%   
    CTCOR       3.154540    4.431616    6.048591    8.173215    18.402186  \
    eTh         7.069359   10.068416   13.000383   17.348894    43.680056   
    eU          0.608489    1.145814    1.557596    2.040708     4.745353   
    KPERC       0.191215    0.554413    0.994675    1.500575     4.058816   
    MDT       690.155134  784.967941  860.787455  914.670357  1228.611583   
    THKRAZAO    6.038603    9.399438   13.684541   22.592692   143.212420   
    UTHRAZAO    0.071637    0.096820    0.117252    0.141150     0.298901   
    UKRAZAO     0.655872    1.070815    1.577790    2.728593    16.920483   
    
                      max  
    CTCOR       20.403574  
    eTh         49.119072  
    eU           5.759232  
    KPERC        4.530206  
    MDT       1282.455697  
    THKRAZAO   216.822093  
    UTHRAZAO     0.335752  
    UKRAZAO     23.079396  



    
![png](output_64_1.png)
    



```python
plot_raw_gama_data(df,suptitle='Dados Radiométricos interpolados (Algoritmo: Linear)',figsize=(27,16))
df.rename(columns={'GMT':'MAGIGRF'},inplace=True)
plot_raw_mag_data(df,suptitle='Dados Magnetométricos interpolados (Algoritmo: Linear)')
```


    
![png](output_65_0.png)
    



    
![png](output_65_1.png)
    


### Pixel size


```python
df_rs = df
df_rs.rename(columns={'X':'E_utm','Y':'N_utm'},inplace=True)
#df_rs.fillna(0,inplace=True)

xpixel_size = (df_rs.E_utm.max()-df_rs.E_utm.min())/df_rs.E_utm.unique().size
ypixel_size = (df_rs.N_utm.max()-df_rs.N_utm.min())/df_rs.N_utm.unique().size
print('x:', xpixel_size, 'y:', ypixel_size)

nx=df_rs.E_utm.unique().size
ny=df_rs.N_utm.unique().size
ratio=ny/nx
xs = df_rs.E_utm.values.reshape(ny, nx)
ys = df_rs.N_utm.values.reshape(ny, nx)

features = list(df_rs.columns[2:])

plot_corr(df_rs[features], size=11)
#plt.savefig('figs/correlation_matrix.png', dpi=400, bbox_inches='tight')
```

    x: 100.16579455615407 y: 100.21072649280123



    
![png](output_67_1.png)
    



```python
data = StandardScaler().fit_transform(df[features].values)

# data = df_rs[features].values

# NÚMERO DE CLASSES
n_clusters=5
lito_SOM = SOM(m=n_clusters,
               n=1,
           sigma=1.5,
             dim=len(features),
        max_iter=10000)

lito_SOM.fit(data)

# predição de classes
predictions = lito_SOM.predict(data)

# create labels
cluster_labels=[]
for i in range(n_clusters):
    cluster_labels+=[f'Classe {i+1}']
    
# classes weights
fig, ax = plt.subplots(figsize=(19,19))
im=ax.matshow(lito_SOM.weights)
for (i, j), z in np.ndenumerate(lito_SOM.weights):
    ax.text(j, i, '{:0.2f}'.format(z), ha='center', va='center')

plt.yticks(range(n_clusters), cluster_labels, fontsize=9)
plt.xticks(range(len(features)), features, rotation=55, fontsize=10, ha='left')
fig.colorbar(im, label='weights', orientation='horizontal')
plt.gca().set_aspect('equal')
plt.gcf().set_size_inches(10, 10)
plt.show()
```


    
![png](output_68_0.png)
    



```python
id_ = [1,2,3,4,5]
relcolor =  matplotlib.cm.Set3
colors = np.array(relcolor.colors)[id_]
relcolor = matplotlib.colors.ListedColormap(colors)

idxs=np.arange(0, n_clusters, 1)
half=(idxs[1]-idxs[0])/2
ticks=np.linspace(idxs[0]+half, idxs[-1]-half, n_clusters)

datafig, ax=plt.subplots(figsize=(12, 12), facecolor='w')
im=plt.pcolormesh(xs, ys, predictions.reshape(ny, nx), cmap=relcolor, shading='auto')
plt.xlim(xs.min(), xs.max())
plt.ylim(ys.min(), ys.max())

cbar_ax = fig.add_axes([0.93, 0.3, 0.05, 0.4])
cbar = fig.colorbar(im, cax=cbar_ax, label = u'Classes', orientation='vertical',cmap='viridis',ticks=ticks)
cbar.ax.set_yticklabels(cluster_labels, fontsize=8)


plt.suptitle('SOM - Aerogeophysical Data (SF23_YA_III4)')
plt.axis('scaled')
plt.tight_layout()
plt.show()

```


    
![png](output_69_0.png)
    



```python
n_clusters=11
lito_SOM = SOM(m=n_clusters, n=1, sigma=1.5, dim=len(features), max_iter=10000)
lito_SOM.fit(data)

# predição de classes
predictions = lito_SOM.predict(data)

# create labels
cluster_labels=[1,2,3,4,5,6,7,8,9,10,11]
for i in range(n_clusters):
    cluster_labels+=[f'Classe {i+1}']
    
# classes weights
fig, ax = plt.subplots(figsize=(27,27))
im=ax.matshow(lito_SOM.weights)

for (i, j), z in np.ndenumerate(lito_SOM.weights):
    ax.text(j, i, '{:0.2f}'.format(z), ha='center', va='center')

plt.yticks(range(n_clusters), cluster_labels, fontsize=8)
plt.xticks(range(len(features)), features, rotation=55, fontsize=9, ha='left')
fig.colorbar(im, label='weights', orientation='horizontal',cmap='Reds')
plt.gca().set_aspect('equal')
plt.gcf().set_size_inches(15, 10)
plt.show()

id_ = [1,2,3,4,5,6,7,8,9,10,11]

relcolor =  matplotlib.cm.Set3
colors = np.array(relcolor.colors)[id_]
relcolor = matplotlib.colors.ListedColormap(colors)

idxs=np.arange(0, n_clusters, 1)
half=(idxs[1]-idxs[0])/2
ticks=np.linspace(idxs[0]+half, idxs[-1]-half, n_clusters)

datafig, ax=plt.subplots(figsize=(12, 12), facecolor='w')
im=plt.pcolormesh(xs, ys, predictions.reshape(ny, nx), cmap=relcolor, shading='auto')
plt.xlim(xs.min(), xs.max())
plt.ylim(ys.min(), ys.max())
cbar_ax = fig.add_axes([0.93, 0.3, 0.05, 0.4])
cbar = fig.colorbar(im, cax=cbar_ax, label = u'Classes', orientation='vertical',
                    ticks=ticks)
cbar.ax.set_yticklabels(cluster_labels, fontsize=8)
plt.suptitle('SOM - Aerogeophysical Data ()')
plt.axis('scaled')
plt.show()
```

### Testes


```python
plt.figure(figsize=(24,16))

# PLOTANDO A MALHA CARTOGRÁFICA
for id in list(quadricula.keys()):
    carta=quadricula[id]
    plt.plot(*transform_to_carta_utm(carta['folha']).exterior.xy,color='black')
    
    # PLOTANDO OS DADOS INTERPOLADOS
    for data in list(carta.keys())[2:]:        
        if 'geof' in data:
            plt.scatter(carta[data].X,carta[data].Y,c=carta[data].eU,cmap='rainbow',s=0.5,marker='H')
            plt.axis('scaled')
        # SE NÃO TIVER DADOS NÃO PLOTA NADA
        else:
            pass
        
plt.suptitle('Área de cobertura dos levantamentos aerogeofísicos')
plt.tight_layout()
```


```python
df = quadricula['SF23_YA_III4']['geof_1105_linear']

plot_histograms(df)
plot_raw_gama_data(df,suptitle='Dados Radiométricos interpolados (Algoritmo: Linear)',figsize=(27,16))
plot_raw_mag_data(df,suptitle='Dados Magnetométricos i4nterpolados (Algoritmo: Linear)')


df_rs = df
df_rs.rename(columns={'X':'E_utm','Y':'N_utm'},inplace=True)
#df_rs.fillna(0,inplace=True)


xpixel_size = (df_rs.E_utm.max()-df_rs.E_utm.min())/df_rs.E_utm.unique().size
ypixel_size = (df_rs.N_utm.max()-df_rs.N_utm.min())/df_rs.N_utm.unique().size
print('x:', xpixel_size, 'y:', ypixel_size)


nx=df_rs.E_utm.unique().size
ny=df_rs.N_utm.unique().size
ratio=ny/nx
xs = df_rs.E_utm.values.reshape(ny, nx)
ys = df_rs.N_utm.values.reshape(ny, nx)

features = list(df_rs.columns[2:])
print(features)


plot_corr(df_rs[features], size=12)
#plt.savefig('figs/correlation_matrix.png', dpi=400, bbox_inches='tight')



scaler = StandardScaler()
data = scaler.fit_transform(df[features].values)
# data = df_rs[features].values


n_clusters=9
lito_SOM = SOM(m=n_clusters, n=1, sigma=1.5, dim=len(features), max_iter=10000)
lito_SOM.fit(data)

# predição de classes
predictions = lito_SOM.predict(data)
```


```python
# create labels
cluster_labels=[1,2,3,4,5,6,7,8,9]
for i in range(n_clusters):
    cluster_labels+=[f'Classe {i+1}']
    
# classes weights
fig, ax = plt.subplots(figsize=(19,26))
im=ax.matshow(lito_SOM.weights)
for (i, j), z in np.ndenumerate(lito_SOM.weights):
    ax.text(j, i, '{:0.2f}'.format(z), ha='center', va='center')

plt.yticks(range(n_clusters), cluster_labels, fontsize=9)
plt.xticks(range(len(features)), features, rotation=55, fontsize=10, ha='left')
fig.colorbar(im, label='weights', orientation='horizontal')
plt.gca().set_aspect('equal')
plt.gcf().set_size_inches(19, 26)
plt.show()
```


```python
id_ = [1,2,3,4,5,6,7,8,9]
relcolor =  matplotlib.cm.Set3
colors = np.array(relcolor.colors)[id_]
relcolor = matplotlib.colors.ListedColormap(colors)



idxs=np.arange(0, n_clusters, 1)
half=(idxs[1]-idxs[0])/2
ticks=np.linspace(idxs[0]+half, idxs[-1]-half, n_clusters)

datafig, ax=plt.subplots(figsize=(16, 16), facecolor='w')
im=plt.pcolormesh(xs, ys, predictions.reshape(ny, nx), cmap=relcolor, shading='auto')
plt.xlim(xs.min(), xs.max())
plt.ylim(ys.min(), ys.max())
cbar_ax = fig.add_axes([0.93, 0.3, 0.05, 0.4])
cbar = fig.colorbar(im, cax=cbar_ax, label = u'Classes', orientation='vertical',
                    ticks=ticks)
cbar.ax.set_yticklabels(cluster_labels, fontsize=8)
plt.suptitle('SOM - Aerogeophysical Data (SF23_YA_III4)')
plt.axis('scaled')
plt.show()
```

# Classificações Supervisionadas

## Rotulando amostras com classes litológicas


```python
import shapely.speedups
from shapely import geometry
shapely.speedups.enable()

geof_1089_linear['geometry'] = [geometry.Point(x,y) for x, y in zip(geof_1089_linear['X'], geof_1089_linear['Y'])]
gdf_1089_linear = geof_1089_linear.set_geometry('geometry')

gdf_1089_linear.set_crs('EPSG:32723',inplace=True)
gdf_1089_linear.geometry
```


```python
Upload_litologia(quadricula,'litologia_100k')
```


```python
litologia=quadricula['SB24_ZB_II']['litologia_100k']
litologia.to_crs('EPSG:32724',inplace=True)
print(litologia.crs)
litologia.reset_index(drop=True,inplace=True)

dic_litologico = describe_geologico(litologia)
print(litologia.columns)
```


```python
print(dic_litologico['SIGLA']['len'])
print(dic_litologico['SIGLA']['lista'])
gdf_1089_linear
```


```python
litologia.plot('SIGLA',figsize=(16,16),legend=True)
```


```python
geof_1089_linear['closest_unit'] = geof_1089_linear['geometry'].apply(lambda x: litologia['SIGLA'].iloc[litologia.distance(x).idxmin()]) # .idxmin() Retorna o indice do menor valor 
```


```python
geof_1089_linear.to_csv('/home/ggrl/database/csv/SB24_ZB_II_gama_linear_100m.csv',index=False)
```
